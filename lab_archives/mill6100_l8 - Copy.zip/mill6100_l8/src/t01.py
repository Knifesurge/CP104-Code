"""
------------------------------------------------------------------------
Lab 8, Task 1
------------------------------------------------------------------------
Author: Nicolas Mills
ID:     180856100
Email:  mill6100@mylaurier.ca
__updated__ = 2018-11-11
------------------------------------------------------------------------
"""
from functions import get_weekday_name

for i in range(7):
    print(get_weekday_name(i))