"""
------------------------------------------------------------------------
Lab 10, Task 6
------------------------------------------------------------------------
Author: Nicolas Mills
ID:     180856100
Email:  mill6100@mylaurier.ca
__updated__ = 2018-11-26
------------------------------------------------------------------------
"""
from functions import words_to_matrix, print_matrix_char

strings = ["cat", "dog", "bat"]

matrix = words_to_matrix(strings)

print_matrix_char(matrix)