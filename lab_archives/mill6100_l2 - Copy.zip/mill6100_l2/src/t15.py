"""
------------------------------------------------------------------------
Lab 2, Task 15
------------------------------------------------------------------------
Author: Nicolas Mills
ID:     180856100
Email:  mill6100@mylaurier.ca
__updated__ = 2018-09-17
------------------------------------------------------------------------
"""
integer = 654321
decimal = 654.32
phrase = "Hello World"

print(integer)
print(float(integer))
print(str(integer))

print(int(decimal))
print(decimal)
print(str(decimal))

#print(int(phrase))
#print(float(phrase))
print(phrase)