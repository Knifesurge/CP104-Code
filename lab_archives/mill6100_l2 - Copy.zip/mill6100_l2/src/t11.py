"""
------------------------------------------------------------------------
Lab 2, Task 11
------------------------------------------------------------------------
Author: Nicolas Mills
ID:     180856100
Email:  mill6100@mylaurier.ca
__updated__ = 2018-09-17
------------------------------------------------------------------------
"""
location1 = "left"
location2 = "middle"
location3 = "right"

print("{:-<16s}".format(location1))
print("{:-^16s}".format(location2))
print("{:->16s}".format(location3))