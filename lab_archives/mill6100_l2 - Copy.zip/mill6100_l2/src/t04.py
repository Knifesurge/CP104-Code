"""
------------------------------------------------------------------------
Lab 2, Task 4
------------------------------------------------------------------------
Author: Nicolas Mills
ID:     180856100
Email:  mill6100@mylaurier.ca
__updated__ = 2018-09-17
------------------------------------------------------------------------
"""
total = 500
percent = 10
discount = total * (percent / 100)
print("A {} percent discount on {} is {}".format(percent, total, discount))