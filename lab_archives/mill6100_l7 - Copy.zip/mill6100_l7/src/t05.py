"""
------------------------------------------------------------------------
Lab 7, Task 5
------------------------------------------------------------------------
Author: Nicolas Mills
ID:     180856100
Email:  mill6100@mylaurier.ca
__updated__ = 2018-11-05
------------------------------------------------------------------------
"""
from functions import password_strength

password = input("Enter a password: ")

password_strength(password)