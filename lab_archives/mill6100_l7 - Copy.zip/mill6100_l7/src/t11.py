"""
------------------------------------------------------------------------
Lab 7, Task 11
------------------------------------------------------------------------
Author: Nicolas Mills
ID:     180856100
Email:  mill6100@mylaurier.ca
__updated__ = 2018-11-05
------------------------------------------------------------------------
"""
from functions import dsmvwl

string = input("Enter a string: ")

disemvowelled = dsmvwl(string)

print("Disemvowelled: {}".format(disemvowelled))