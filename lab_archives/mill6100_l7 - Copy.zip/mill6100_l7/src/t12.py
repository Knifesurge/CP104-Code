"""
------------------------------------------------------------------------
Lab 7, Task 12
------------------------------------------------------------------------
Author: Nicolas Mills
ID:     180856100
Email:  mill6100@mylaurier.ca
__updated__ = 2018-11-05
------------------------------------------------------------------------
"""
from functions import comma_period_replace

text = input("Enter a string: ")

print(comma_period_replace(text))