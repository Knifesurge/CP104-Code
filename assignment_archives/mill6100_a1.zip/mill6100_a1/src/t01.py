"""
------------------------------------------------------------------------
Assignment 1, Task 1
------------------------------------------------------------------------
Author: Nicolas Mills
ID:     180856100
Email:  mill6100@mylaurier.ca
__updated__ = 2018-09-14
------------------------------------------------------------------------
"""
print('The book title is, "Learn Python in 21 Days".')
print("What's mine is mine, and what's yours is mine.")
print('''"You have enemies? Good. That means you've stood up for something, sometime in your life." Winston Churchill''')
print('''
Three things cannot be long hidden:
the sun,
the moon,
and the truth.
''')