"""
------------------------------------------------------------------------
Assignment 1, Task 2
------------------------------------------------------------------------
Author: Nicolas Mills
ID:     180856100
Email:  mill6100@mylaurier.ca
__updated__ = 2018-09-14
------------------------------------------------------------------------
"""
fav_tv_show = input("Favourite TV Show: ")
fav_food = input("Favourite Food: ")

print("I like to eat {} while watching {}.".format(fav_food, fav_tv_show))