"""
------------------------------------------------------------------------
Assignment 7, Task 7
------------------------------------------------------------------------
Author: Nicolas Mills
ID:     180856100
Email:  mill6100@mylaurier.ca
__updated__ = 2018-11-16
------------------------------------------------------------------------
"""
from functions import pluralize

string = input("Enter a string: ")

plural = pluralize(string)

print("Plural: {}".format(plural))